<?php

/**
 * This file is part of LEPTON Core, released under the GNU GPL
 * Please see LICENSE and COPYING files in your package for details, specially for terms and warranties.
 *
 * NOTICE:LEPTON CMS Package has several different licenses.
 * Please see the individual license in the header of each single file or info.php of modules and templates.
 *
 * @author          LEPTON Project
 * @copyright       2020 LEPTON Project
 * @link            https://lepton-cms.org
 * @license         http://www.gnu.org/licenses/gpl.html
 * @license_terms   please see LICENSE and COPYING files in your package
 */


// set error level
 ini_set('display_errors', 1);
 error_reporting(E_ALL|E_STRICT);

echo ('<h3>Current process: updating to LEPTON 5.0.0</h3>');

// make sure algos is not used any longer
if ( DEFAULT_THEME == 'algos' )
{
	// switch theme
	echo '<h5>Current process: switch theme to LEPSem (new standard theme)</h5>';
	LEPTON_handle::register('switch_theme');
	switch_theme('lepsem');

	echo(LEPTON_tools::display('Please keep in mind that you now have to login with '.LEPTON_URL.'/backend ', 'pre','ui red message'));
	echo(LEPTON_tools::display('You can switch to new Talgos via /options ', 'pre','ui blue message'));
	echo "<h5>Switch theme to LEPSem: successfull</h5>";
}

// upgrade field login_ip: https://forum.lepton-cms.org/viewtopic.php?f=27&p=13323#p13323
echo '<h5>Current process: extend field length login_ip in users table</h5>';
$check = $database->simple_query("ALTER TABLE ".TABLE_PREFIX."users CHANGE `login_ip` `login_ip` VARCHAR(64) NOT NULL DEFAULT '' ");
echo "<h5>Extend field length: successfull</h5>";

// insert new field in setting table
$check = $database->get_one( "SELECT `name` FROM `".TABLE_PREFIX."settings` WHERE `name` = 'wysiwyg_history'" );
if ( true === is_null( $check ))
{
	echo '<h5>Current process: insert new field in setting table</h5>';
	$database->simple_query("INSERT INTO `".TABLE_PREFIX."settings` (`setting_id`, `name`, `value`) VALUES (NULL, 'wysiwyg_history', 'false')");
	echo "<h5>Insert new field in setting table: successfull</h5>";
}

/* not to do in script
Alter db to utf8mb4? https://forum.lepton-cms.org/viewtopic.php?f=20&t=5333&p=13247#p13254
*/

// remove obsolete files: https://forum.lepton-cms.org/viewtopic.php?f=20&t=5301
echo '<h5>Current process: delete not needed files and directories</h5>';
// [1] directories
$directory_names = array(
	'/admins',
	'/include',
	'/templates/algos',
	'/modules/jsadmin'	
);
LEPTON_handle::delete_obsolete_directories( $directory_names );

// [2] files
$file_names = array(
	'/framework/classes/class.admin_phplib.php',
	'/framework/classes/lepton_xrun.php',
	'/framework/functions/function.switch_theme.php',
	'/modules/lib_jquery/external/jquery.idTabs.min.js',
	'/modules/lib_jquery/external/jquery.MetaData.js',
	'/modules/lib_jquery/external/jquery.MultiFile.pack.js',
	'/modules/lib_jquery/external/jquery-insert.js',
	'/modules/lib_jquery/external/jquery-plugins.js',
	'/modules/lib_jquery/external/jquery-pngFix.js',
	'/modules/lib_jquery/external/webkit_fix.js',
	'/templates/lepsem/languages/NO.php'	// no supported language	
);
LEPTON_handle::delete_obsolete_files( $file_names );
echo "<h5>Delete not needed files and directories: successfull</h5>";


// install new modules
echo '<h5>Current process: run modules install.php</h5>';
$module_names = array(
	"lib_comp"
);
LEPTON_handle::install_modules($module_names);
echo "<h5>run install.php of new modules: successfull</h5>";


// upgrade updated modules
echo '<h5>Current process: run modules upgrade.php</h5>';
$module_names = array(
	"addon_info",
	"captcha_control",
	"code2",
	"cookie",
	"droplets",
	"initial_page",
	"lib_fomantic",
	"lib_lepton",
	"lib_phpmailer",
	"lib_r_filemanager",
	"lib_search",
	"lib_twig",
	"menu_link",
	"news",
	"quickform",
	"reset_pin",
	"show_menu2",
	"tinymce",	
	"wrapper",
	"wysiwyg",
	"wysiwyg_admin"
);
LEPTON_handle::upgrade_modules($module_names);
echo "<h5>run upgrade.php of modified modules: successfull</h5>";


// update release and success message
echo ('<h5>Current process: set new release number</h5>');
$database->simple_query("UPDATE ".TABLE_PREFIX."settings SET value ='5.0.0' WHERE name = 'lepton_version' ");
echo "<h3>update to LEPTON 5.0.0 successfull!</h3><br />";
