<?php

/**
 *  @module         code2
 *  @version        see info.php of this module
 *  @authors        Ryan Djurovich, Chio Maisriml, Thomas Hornik, Dietrich Roland Pehlke
 *  @copyright      2010-2020 Ryan Djurovich, Chio Maisriml, Thomas Hornik, Dietrich Roland Pehlke
 *  @license        GNU General Public License
 *  @license terms  see info.php of this module
 *  @platform       see info.php of this module
 *
 */

function code2_search($func_vars) {
	extract($func_vars, EXTR_PREFIX_ALL, 'func');
	
	// how many lines of excerpt we want to have at most
	$max_excerpt_num = $func_default_max_excerpt;
	$divider = ".";
	$result = false;
	
	$content = array();
	$func_database->execute_query(
		"SELECT `content` from `".TABLE_PREFIX."mod_code2` WHERE `section_id`=".$func_section_id." AND `whatis` IN (1, 11, 21)",
		true,
		$content,
		false
	);
	if(count($content) > 0)
	{
    	$mod_vars = array(
			'page_link' => $func_page_link,
			'page_link_target' => "#wb_section_".$func_section_id,
			'page_title' => $func_page_title,
			'page_description' => $func_page_description,
			'page_modified_when' => $func_page_modified_when,
			'page_modified_by' => $func_page_modified_by,
			'text' => $content['content'].$divider,
			'max_excerpt_num' => $max_excerpt_num
		);
		if(print_excerpt2($mod_vars, $func_vars)) {
			$result = true;
		}

	}
	return $result;
}

?>