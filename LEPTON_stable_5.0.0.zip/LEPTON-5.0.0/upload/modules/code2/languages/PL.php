<?php

/**
 *  @module         code2
 *  @version        see info.php of this module
 *  @authors        Ryan Djurovich, Chio Maisriml, Thomas Hornik, Dietrich Roland Pehlke
 *  @copyright      2010-2020 Ryan Djurovich, Chio Maisriml, Thomas Hornik, Dietrich Roland Pehlke
 *  @license        GNU General Public License
 *  @license terms  see info.php of this module
 *  @platform       see info.php of this module
 *
 */

global $MOD_CODE2;

$MOD_CODE2 = array (
	'PHP'	=> "PHP",
	'HTML'	=> "HTML",
	'JAVASCRIPT'	=> "Java skrypt",
	'INTERNAL'	=> "Wewnętrzne komentarze",
	'ADMIN'	=> "Komentarz Admina",
	'SMART'	=> "smart",
	'FULL'	=> "full",
	'MODE'	=> "Widok"
);
