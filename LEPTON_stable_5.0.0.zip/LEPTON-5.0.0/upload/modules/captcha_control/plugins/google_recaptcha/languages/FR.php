<?php

/**
 * This file is part of an ADDON for use with LEPTON Core.
 * This ADDON is released under the GNU GPL.
 * Additional license terms can be seen in the info.php of this module.
 *
 *
 *	@module			captcha plugin: google_recaptcha
 *	@version		see info.php of this module
 *	@authors		Thomas Hornik (thorn),LEPTON Project
 *	@copyright		2008-2010, Thomas Hornik (thorn)
 *	@copyright		2010-2020  LEPTON Project
 *	@link			https://lepton-cms.org
 *	@license		http://www.gnu.org/licenses/gpl.html
 *	@license terms	see info.php of this module
 *	@platform		see info.php of this module
 *
 *
 */

 // include class.secure.php to protect this file and the whole CMS!
if (defined('LEPTON_PATH')) {
	include(LEPTON_PATH.'/framework/class.secure.php');
} else {
	$oneback = "../";
	$root = $oneback;
	$level = 1;
	while (($level < 10) && (!file_exists($root.'/framework/class.secure.php'))) {
		$root .= $oneback;
		$level += 1;
	}
	if (file_exists($root.'/framework/class.secure.php')) {
		include($root.'/framework/class.secure.php');
	} else {
		trigger_error(sprintf("[ <b>%s</b> ] Can't include class.secure.php!", $_SERVER['SCRIPT_NAME']), E_USER_ERROR);
	}
}
// end include class.secure.php

/*
 * Important note
 * ==============
 * This translation file is merged during plugin processing with the captcha module
 * translation file, whereas this plugin translation has a higher priority and may 
 * overwrite any translation defined in the captcha main.
 * However, this translation file here should contain only translations used in this plugin
 * if not already defined in main captcha translation file or divers from there.
 */
 
/* ==============================================
 * translated via...: LEPTON CMS module languager
 * translated at....: 12:56, 28-06-2020
 * translated from..: EN
 * translated to....: FR
 * translated using.: www.DeepL.com/Translator
 * ==============================================
 */

$MOD_PLUGIN	= array(
	"CCL_CAPTCHALABEL"			=> "Label défini pour le Captcha",
	"CCL_GOOGLE_CONFIG"			=> "Paramètres de configuration de Google reCAPTCHA",
	"CCL_GOOGLE_REGISTER"		=> "Paramètres d'enregistrement de Google reCAPTCHA",
	"CCL_ITEM_V2_CHECKBOX"		=> "reCAPTCHA Version 2 - Case à cocher",
	"CCL_ITEM_V2_COMPACT"		=> "compact",
	"CCL_ITEM_V2_DARK"			=> "sombre",
	"CCL_ITEM_V2_INVISIBLE"		=> "reCAPTCHA Version 2 - Invisible",
	"CCL_ITEM_V2_LIGHT"			=> "léger (* par défaut)",
	"CCL_ITEM_V2_NORMAL"		=> "normal (* par défaut)",
	"CCL_ITEM_V3"				=> "reCAPTCHA Version 3",
	"CCL_SECUREKEY"				=> "Clé sécurisée de Google",
	"CCL_SITEKEY"				=> "Clé du site Google",
	"CCL_SIZE"					=> "Taille",
	"CCL_THEME"					=> "Thème",
	"CCL_VERSION"				=> "Version de Google reCAPTCHA",
	"GOOGLE_RECAPTCHA"			=> "Google Recaptcha"
);

?>
