### Cookie
============

A LEPTON tool to get users informed about cookies.

#### Requirements

* [LEPTON CMS][1], Version > 4.0


#### Installation

Cookie is now part of LEPTON package and is installed during setup process.
If not, you can install it manually via backend after upload files vis ftp or 

* use installation archive
* in CMS backend select the file from "Add-ons" -> "Modules" -> "Install module"

#### Notice

After installing addon you are done. <br />
Please go to "Admintools" in the backend and use it!

For further informations please read [the readme file][2]


[1]: https://lepton-cms.org "LEPTON CMS"
[2]: http://cms-lab.com/_documentation/cookie/readme.php
