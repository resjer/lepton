Copyright 2008 Christophe Dolivet

Homepage:
http://www.cdolivet.com/editarea/

Complete documentation:
http://www.cdolivet.com/editarea/editarea/docs/

All licenses:
http://www.cdolivet.com/editarea/editarea/docs/

Examples:
http://www.cdolivet.com/editarea/editarea/exemples/exemple_full.html